import React from 'react'
import { FaCertificate, FaLayerGroup,FaUsers,FaPencilRuler } from "react-icons/fa";
const KeyStates = () => {
  return (
    <>
              <ul className='list-unstyled d-flex justify-content-between flex-sm-wrap w-75 m-auto'>
                  <li>
            <KeyStatesItem
              keyIcon={<FaCertificate />}
              keyNum={'15+'}
              keyDes={'Years of Experience'} 
              
              />
                  </li>
                  <li>
                  <KeyStatesItem
                    keyIcon={<FaLayerGroup />}
                    keyNum={'10000+'}
                    keyDes={'Successful Deep-Drive Market '} 
              />
                  </li>
                  <li>
                  <KeyStatesItem
                    keyIcon={<FaUsers />}
                    keyNum={'550+'}
                    keyDes={'Clients Accross the Globe'} 
            />
                  </li>
                  <li>
                  <KeyStatesItem
                    keyIcon={<FaPencilRuler />}
                    keyNum={'375+'}
                    keyDes={'Consulting Projects'} 
            />
                  </li>
        </ul>      
    </>
  )
}
const KeyStatesItem = ({keyIcon,keyNum,keyDes}) => {
    return (
        <>
            <div className='card shadow mt-md-3'>
              <div className='card-body text-center'>
                    <h1>{keyIcon}</h1>
                    <h2>{keyNum}</h2>
                    <p>{keyDes}</p>
              </div>
          </div>
        </>
    )
}

export default KeyStates
