const express = require('express')
var app = express()
const router = express.Router()
const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost:27017/mern-stack', { useNewUrlParser: true, useUnifiedTopology: true }, (err) => {
    if (err)
        console.log(err)
    else
        console.log('mongodb connection successful')
})

var Usermodel = mongoose.model('user', {
    name: String,
    username: String,
    password:String
})

router.post('/registeruser', (req, res) => {
    var newuser = new Usermodel({
        name: req.body.name,
        username: req.body.username,
        password:req.body.password
    })
    newuser.save((err) => {
        if (err)
            res.send('something went wrong')
        else
            res.send('user registration successful')
    })
})

router.post('/getusers' , function(req , res){

    Usermodel.find({} , function(err , documents){

            if(err){
                res.send('Something went wrong');
            }
            else{
                res.send(documents);
            }

    })

})

module.exports = router;