import React from 'react';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import testiData from '../data/testiData'
import { FaUserAlt } from "react-icons/fa";
const Testimonials = () => {
    console.log('render')
    const options = {
        items: 3,
        nav: true,
        navText:["<div className='nav-btn prev-slide'></div>","<div className='nav-btn next-slide'></div>"],
        rewind: true,
        autoplay: true,
        slideBy: 1,
        dots: true,
        dotsEach: true,
        dotData: true
      };
  return (
    <section className='testimonial-main'>
        <div className='container'>
              <h2 className='title text-center'>Client <span>Testimonials</span></h2>
              <OwlCarousel className='owl-theme' looref="gallery" {...options} margin={10} nav>
                  {testiData.map((testimonial) => {
                      return (
                  
                    <div className='item'>
                      <div className='card shadow'>
                          <div className='card-body'>
                                <p>{testimonial.testidesc}</p>
                          </div>
                          <div className='card-footer'>
                                  <div className='d-flex'>
                                      <div className='user-icon'><FaUserAlt/></div>
                                      <div className='user-info'>
                                          <h5>{testimonial.company}</h5>
                                          <p>{testimonial.designation}</p>
                                      </div>
                                  </div>
                            </div>
                       </div>
                      </div>
                      )})}
              </OwlCarousel>
        </div>
    </section>
  )
}

export default Testimonials
