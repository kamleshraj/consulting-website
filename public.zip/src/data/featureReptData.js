const featureReptData = [
    {
        id: 1,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010760/consulting-app/cat-icons/Agriculture_ta8949.svg',
        catname:'Agriculture, Food well-informed decisions. Key players in the global MicroRNA Tools and Services Market key developments, and growth strategies.'
    },
    {
        id: 2,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010768/consulting-app/cat-icons/Telecom-and-IT_kise03.svg',
        catname:'This report covers market segmentation by major market verdors, types, applications/end users and geography(North America.'
    },
    {
        id: 3,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010768/consulting-app/cat-icons/Chemical-and-Material_twpgwh.svg',
        catname:' This research works as a systematic guideline for marketers to make well-informed decisions data used for this report is obtained from reliable industry sources.'
    },
    
    {
        id: 4,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010759/consulting-app/cat-icons/Services_i8ihcw.svg',
        catname:'Services The data used for this report is obtained from reliable industry sources, tatistical analysis, key developments, and growth strategies.'
    },
    {
        id: 5,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010757/consulting-app/cat-icons/Electronics_z7sebu.svg',
        catname:'Electronics The prime objective of this report is to provide the insights on the post COVID-19 impact which will help market players in this field evaluate their business approaches.'
    },
    
    {
        id: 6,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010757/consulting-app/cat-icons/Healthcare-and-Pharmaceuticals_axvxel.svg',
        catname:'Healthcare-and-Pharmaceuticals The data used for this report is obtained from reliable industry sources, paid resources, and validated sources.'
    }
]

export default featureReptData;