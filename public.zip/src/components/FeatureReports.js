import React from 'react'
import featuredRept from '../data/featureReptData'
const FeatureReports = () => {
  return (
    <section className='featured-main'>
      <div className='container'>
          <h2 className='title text-center'>Feature <span>Reports</span></h2>
          <ul className='featureReport list-unstyled d-flex justify-content-between'>
              {featuredRept.map((report,i) => {
                  return <li className='cat-item card' key={i}><FeatureReport repticon={report.caturl} reptname={report.catname} /></li>
                })} 
          </ul>
      </div>
    </section>
  )
}

const FeatureReport = ({reptname,repticon}) => {
    return (
        <>
        <div className='card-body'>
          <div className='d-flex'>
            <img src={repticon} alt={reptname} />
            <h6 className='p-2'>{reptname}</h6>
          </div>
        </div>
        </>
    )
}

export default FeatureReports
