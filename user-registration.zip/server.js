const express = require('express')
const app = express()
const bodyparser = require('body-parser')
app.use(bodyparser.urlencoded({ extended: true }))
app.use(bodyparser.json())

const userRoutes = require('./Routes/UserRoute')
app.use('/api/user/', userRoutes)


app.get('/', (req, res) => {
    res.send('welcome to my app')
})

app.get('/api/mern/', (req, res) => {
    res.send('This is the Mern from node server.')
})

app.get('/api/getname/', (req, res) => {
    var namelist = ['Ram', 'Shyam', 'Gaurav', 'Rita'];
    res.send(namelist)
})

app.post('/api/validateusername/', (req, res) => {
    var username = req.body.username
    res.send('the received value ' + username)
})

app.listen(5000, () => {
    console.log('server started at port 5000')
})