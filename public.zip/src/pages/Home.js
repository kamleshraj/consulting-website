import Header from "../components/Header";
import { BrowserRouter } from 'react-router-dom';
import Navbar from "../components/Navbar";
import KeyStates from "../components/KeyStates";
import CarousalBanner from './../components/CarousalBanner';

import '../css/main.css'
import Categories from "../components/Categories";
import FeatureReports from "../components/FeatureReports";
import Testimonials from "../components/Testimonials";

const Home = () => {
  return (
    <>
      <BrowserRouter>
        <Header/>
        <Navbar />
      </BrowserRouter>
          <CarousalBanner/>
          <KeyStates/>
          <Categories />  
          <FeatureReports />
          <Testimonials/>
    </>
  )
}
export default Home