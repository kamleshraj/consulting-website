const catIconsData = [
    {
        id: 1,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010761/consulting-app/cat-icons/Aerospace-and-Defense_wlu8wn.svg',
        catname:'Aerospace-and-Defense'
    },
    {
        id: 2,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010760/consulting-app/cat-icons/Agriculture_ta8949.svg',
        catname:'Agriculture, Food and Beverages'
    },
    {
        id: 3,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010768/consulting-app/cat-icons/Telecom-and-IT_kise03.svg',
        catname:'Telecom-and-IT'
    },
    {
        id: 4,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010768/consulting-app/cat-icons/Chemical-and-Material_twpgwh.svg',
        catname:'Chemical-and-Material'
    },
    {
        id: 5,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010764/consulting-app/cat-icons/Automotive_zvrssd.svg',
        catname:'Automotive'
    },
    {
        id: 6,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010759/consulting-app/cat-icons/Services_i8ihcw.svg',
        catname:'Services'
    },
    {
        id: 7,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010757/consulting-app/cat-icons/Electronics_z7sebu.svg',
        catname:'Electronics'
    },
    {
        id: 8,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010757/consulting-app/cat-icons/Construction-and-Manufacturing_mhkrk7.svg',
        catname:'Construction-and-Manufacturing'
    },
    {
        id: 9,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010756/consulting-app/cat-icons/Energy-and-Power_iludgw.svg',
        catname:'Energy-and-Power'
    },
    {
        id: 10,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010758/consulting-app/cat-icons/Consumer-Goods_xwyrhi.svg',
        catname:'Consumer-Goods'
    },
    {
        id: 11,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010756/consulting-app/cat-icons/Mediacal-Device_kux309.svg',
        catname:'Mediacal-Device'
    },
    {
        id: 12,
        caturl: 'https://res.cloudinary.com/dx1jqzwb5/image/upload/v1667010757/consulting-app/cat-icons/Healthcare-and-Pharmaceuticals_axvxel.svg',
        catname:'Healthcare-and-Pharmaceuticals'
    }
]

export default catIconsData;