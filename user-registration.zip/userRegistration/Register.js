import React,{useState} from 'react'
import axios from 'axios'


const Register = () => {
  const [user, setUser] = useState({
    name: "",
    username:"",
    password:""
  })
  const handleChange = (e) => {
    const name = e.target.name;
    const value = e.target.value;
    setUser({ ...user, [name]: value });
  };
  
  const register = (e) => {
    e.preventDefault()
    axios.post('/api/user/registeruser', user)
      .then(res => {
        console.log(res)
        setUser({ name: '', username: "", password: "" })
      })
      .catch(err => {
        console.log(err)
      })
  }

  return (
    <div className='container'>
    <div className='card shadow mt-md-4 m-auto'>
          <div className='card-header  h4 p-3 bg-success text-white'>User Registration</div>
      <div className='card-body'>
        <form onSubmit={register}>
          <div className='row'>
            <div className="form-floating mb-3 col-md-4">
            <input type="text" name='name' value={user.name} onChange={handleChange}
              className="form-control" id="floatingInput" placeholder="name@example.com" />
            <label htmlFor="floatingInput">Name</label>
            </div>
            <div className="form-floating mb-3 col-md-4">
            <input type="text" name='username' value={user.username} onChange={handleChange}
              className="form-control" id="floatingInput" placeholder="name@example.com" />
            <label htmlFor="floatingInput">Username</label>
            </div>
            <div className="form-floating col-md-4">
            <input type="text" name='password' value={user.password} onChange={handleChange}
              className="form-control" id="floatingPassword" placeholder="Password" />
            <label htmlFor="floatingPassword">Password</label>
            </div>
            </div>
            <div className='text-right'><button className='btn btn-outline-success btn-lg mt-3 fw-bolder'>Submit Form</button></div> 
          </form>    
      </div>
      </div>
      
  </div>
  )
}

export default Register
