import React from 'react'
import { Link } from "react-router-dom";
import { FaEnvelope, FaPhoneAlt } from "react-icons/fa";
const Header = () => {
  return (
      <>
          <header className='bg-dark p-2'>
                <div className='container-fluid'>
                    <ul className='mb-0 list-unstyled d-flex justify-content-between text-white align-items-center'>
                      <li>
                          <div className='d-flex justify-content-between align-items-center'>
                           <div className='email item'> <FaEnvelope/>  <strong> Email : </strong><Link to="/"> sales@consulting.com</Link></div>
                           <div className='phone item px-4'> <FaPhoneAlt/>  <strong> Contact Us : </strong> <Link to="/"> +91 689-098-4556</Link></div>
                          </div>
                      </li>
                      <li>
                         <button className='btn btn-warning fw-bold'>Custom Report</button> 
                     </li>
                    </ul>
                </div>
          </header>
    </>
  )
}

export default Header
