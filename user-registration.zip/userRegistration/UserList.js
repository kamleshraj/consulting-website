import React,{useEffect,useState} from 'react'
import axios from 'axios'


const UserList = () => {
    const [userlist, setUserList] = useState([])
    
    useEffect(()=>{
    axios.post('/api/user/getusers').then(
            res=>{
                console.log(res);
                setUserList(res.data)
            }
        ).catch(err=>{
            console.log(err);
        })
    }, [])
    
  return (
      <>
       <div className='container'>
          <table className='table table-hover table-striped mt-5'>
              <thead>
                  <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Username</th>
                    <th scope="col">Password</th>
                  </tr>
              </thead>
              <tbody>
                  {userlist.map((item) => {
                      const {name,username,password} = item
                    return <tr>
                          <td>{name}</td>
                        <td>{username}</td>
                        <td>{password}</td>
                      </tr>
                  })}
              </tbody>
          </table>
          </div>   
    </>
  )
}

export default UserList
