import React from 'react'
import iconData from '../data/CatIcons'


const Categories = () => {
  return (
      <div className='container'>
          <div className='categories-section py-md-5'>
              <h2 className='title'>Popular <span>Categories</span></h2>
              <ul className='categories-items list-unstyled d-flex justify-content-between flex-sm-wrap'>
              {iconData.map((icon,i) => {
                  return <li className='cat-item' key={i}><CatItem caticon={icon.caturl} catname={icon.catname} /></li>
                })} 
              </ul>
          </div>
    </div>
  )
}

const CatItem = ({caticon,catname}) => {
    return (
        <>
            <div className='card cat-item'>
                <div className='card-body'>
                <img src={caticon} alt={catname} className="cat-icon img-fluid"/>
                <h5>{catname}</h5>
                </div>
            </div>
           
        </>
    )
}

export default Categories
